Figures used in LDA notebook.
