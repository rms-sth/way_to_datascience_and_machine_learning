Figures used for Naive Bayes Classifier notebook
