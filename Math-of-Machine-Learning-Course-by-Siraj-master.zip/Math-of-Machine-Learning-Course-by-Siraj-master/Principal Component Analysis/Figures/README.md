Figures used in the PCA notebook. 
